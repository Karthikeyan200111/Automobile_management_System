
package automobile;
import java.sql.*;
import java.sql.Connection;


/**
 *
 * @author karthikeyan
 */
public class example {
    
    public static void main (String[] args) {
        
        
        
        String url="http://localhost/phpmyadmin/index.php?route=/sql&db=car_details&table=car1&pos=0";
        String user ="root";
        String pass="";
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url,user,pass);
           
            System.out.println("drive successfull");
        }catch(ClassNotFoundException e){
            System.out.print(e);
        }
    }
    
}
