/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package automobile;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author karthikeyan
 */
class DriverManager {

    static Connection getConnection(String jdbcucanaccessCNew_folderMysqlaadb) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static java.sql.Connection getConnection(String url, String user, String pass) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
