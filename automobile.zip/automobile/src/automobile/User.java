/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package automobile;

/**
 *
 * @author karthikeyan
 */
public class User {
    
    
    private int modelno;
    private String carname ;
    private String carcolor;
    private String availability;
    
    public User (int Md,String Carn,String Carc,String Ava){
        
        this.modelno=Md;
        this.carname=Carn;
        this.carcolor=Carc;
        this.availability=Ava;
           
    }
    
    public int getMd(){
        return modelno;
    }
    public String getCarn(){
        
        return carname;
    }
    public String getCarc(){
        
        return carcolor;
    }
    public String getAva(){
        
        return availability;
    }
    
}




